/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'uk', {
	embeddingInProgress: 'Намагаюсь вбудувати вставлене URL посилання...',
	embeddingFailed: 'Це URl посилання не може бути автоматично вбудовано.'
} );
