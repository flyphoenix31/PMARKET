/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'pt-br', {
	embeddingInProgress: 'Tentando embutir a URL colada...',
	embeddingFailed: 'Esta URL não pode ser embutida automaticamente.'
} );
